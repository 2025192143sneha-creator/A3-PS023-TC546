# NEXUS — AIORI-3 PS-023 Prototype

A futuristic React + TypeScript dashboard prototype for a **Minimal Two-Node Cloud Hypervisor VM Controller**.

> **Prototype notice:** All node metrics, VM data, login, health checks, and VM actions are simulated in the browser. This project does not connect to or control real hypervisors. Do not use it as a production control plane.

## Features

- Demo login screen and responsive operator dashboard
- Six sections: Overview, Virtual Machines, Cluster Nodes, Monitoring, Activity Logs, Settings
- Pre-filled sample inventory for two hypervisor nodes and five virtual machines
- Dark mode and light mode
- Searchable VM inventory
- Simulated VM start/stop and create flows
- Downloadable CSV activity log
- Responsive sidebar and mobile layout
- Accessible labels for primary controls

## Demo login

- **Email:** `operator@nexus.demo`
- **Password:** `nexus-demo`

The login is only a UI demonstration; it is not real authentication.

## Run locally

Requires Node.js 18 or newer.

```bash
npm install
npm run dev
```

Open the local URL printed by Vite.

## Production build check

```bash
npm run build
npm run preview
```

## Deploy

This is a Vite app and can be deployed to GitHub Pages, Netlify, or Vercel. For GitHub Pages, configure the deployment workflow for Vite's `dist` output.

## Suggested architecture for the real implementation

1. React UI (this prototype)
2. Auth service with session management and role-based access control
3. Backend API that validates all VM operations and records audit events
4. Hypervisor adapter for libvirt/KVM/QEMU on each node
5. Node heartbeat and metrics collector
6. Explicit authorization, input validation, operation timeouts, and audit logging

Never expose hypervisor credentials or privileged APIs in browser code. A real deployment requires a secured backend and infrastructure testing.

## Problem statement

**AIORI-3 · PS-023 — Minimal Two-Node Cloud Hypervisor VM Controller**

This prototype demonstrates a unified operator interface for observing and managing virtual-machine inventory across two hypervisor nodes. Metrics and controls are illustrative placeholders pending a secure backend adapter.
