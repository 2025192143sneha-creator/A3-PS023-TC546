import { useMemo, useState } from 'react'
import {
  Activity, AlertTriangle, ArrowDownRight, ArrowUpRight, Bell, Check, ChevronDown,
  CircleHelp, Cloud, Command, Cpu, Database, Download, Gauge, HardDrive, LayoutDashboard,
  LockKeyhole, LogOut, Menu, Moon, MoreHorizontal, Network, Plus, Power, Search, Server,
  Settings, ShieldCheck, Sun, Terminal, Timer, Users, X, Zap
} from 'lucide-react'

type Page = 'Overview' | 'Virtual Machines' | 'Cluster Nodes' | 'Monitoring' | 'Activity Logs' | 'Settings'
type VMStatus = 'Running' | 'Stopped' | 'Provisioning'
type VM = { id: string; name: string; image: string; node: string; cpu: number; ram: number; disk: number; status: VMStatus; ip: string }

const initialVMs: VM[] = [
  { id: 'VM-001', name: 'api-gateway-01', image: 'Ubuntu 24.04 LTS', node: 'NODE-01', cpu: 38, ram: 62, disk: 44, status: 'Running', ip: '10.0.1.21' },
  { id: 'VM-002', name: 'postgres-primary', image: 'Debian 12', node: 'NODE-01', cpu: 71, ram: 78, disk: 68, status: 'Running', ip: '10.0.1.22' },
  { id: 'VM-003', name: 'worker-batch-02', image: 'Ubuntu 22.04 LTS', node: 'NODE-02', cpu: 24, ram: 41, disk: 32, status: 'Running', ip: '10.0.2.14' },
  { id: 'VM-004', name: 'staging-web-01', image: 'AlmaLinux 9', node: 'NODE-02', cpu: 0, ram: 0, disk: 19, status: 'Stopped', ip: '10.0.2.18' },
  { id: 'VM-005', name: 'metrics-agent', image: 'Ubuntu 24.04 LTS', node: 'NODE-01', cpu: 12, ram: 26, disk: 21, status: 'Running', ip: '10.0.1.30' },
]
const initialLogs = [
  { time: '22:38:42', type: 'success', title: 'Health check completed', detail: 'Both hypervisor nodes responded within threshold.' },
  { time: '22:34:10', type: 'info', title: 'Snapshot created', detail: 'postgres-primary · snap-2026-1023-04' },
  { time: '22:31:56', type: 'success', title: 'VM migration simulated', detail: 'worker-batch-02 · NODE-01 → NODE-02' },
  { time: '22:18:07', type: 'warning', title: 'Memory threshold crossed', detail: 'NODE-01 memory utilization reached 78%.' },
  { time: '21:59:33', type: 'info', title: 'Access policy updated', detail: 'Operator role · read/write VM controls' },
]
const navItems: { name: Page; icon: typeof LayoutDashboard; group: string }[] = [
  { name: 'Overview', icon: LayoutDashboard, group: 'WORKSPACE' },
  { name: 'Virtual Machines', icon: Server, group: 'WORKSPACE' },
  { name: 'Cluster Nodes', icon: Network, group: 'WORKSPACE' },
  { name: 'Monitoring', icon: Activity, group: 'OBSERVABILITY' },
  { name: 'Activity Logs', icon: Terminal, group: 'OBSERVABILITY' },
  { name: 'Settings', icon: Settings, group: 'SYSTEM' },
]
function Brand() { return <div className="brand-mark"><Command size={19} strokeWidth={2.4}/></div> }
function Status({ status }: { status: string }) {
  const cls = status.toLowerCase()
  return <span className={`status status-${cls}`}><span className="status-dot"/>{status}</span>
}
function Meter({ value, color = 'blue' }: { value: number; color?: string }) {
  return <div className="meter"><div className={`meter-fill ${color}`} style={{ width: `${Math.min(value, 100)}%` }}/></div>
}
function MiniBars() {
  const values = [34, 47, 39, 62, 52, 72, 57, 66, 48, 79, 63, 72, 55, 85, 69, 61, 74, 58, 92, 68, 76, 62, 81, 71]
  return <div className="mini-bars">{values.map((v, i) => <span key={i} style={{ height: `${v}%` }} />)}</div>
}
export default function App() {
  const [loggedIn, setLoggedIn] = useState(false)
  const [email, setEmail] = useState('operator@nexus.demo')
  const [password, setPassword] = useState('nexus-demo')
  const [page, setPage] = useState<Page>('Overview')
  const [dark, setDark] = useState(true)
  const [mobileNav, setMobileNav] = useState(false)
  const [vms, setVms] = useState(initialVMs)
  const [logs, setLogs] = useState(initialLogs)
  const [search, setSearch] = useState('')
  const [notice, setNotice] = useState('')
  const [showCreate, setShowCreate] = useState(false)
  const [vmName, setVmName] = useState('')
  const [vmNode, setVmNode] = useState('NODE-01')
  const [alerts, setAlerts] = useState(true)
  const [autoBalance, setAutoBalance] = useState(true)
  const [confirmLogout, setConfirmLogout] = useState(false)

  const running = vms.filter(v => v.status === 'Running').length
  const filteredVMs = useMemo(() => vms.filter(v => `${v.name} ${v.id} ${v.node} ${v.image}`.toLowerCase().includes(search.toLowerCase())), [vms, search])
  const addLog = (title: string, detail: string, type = 'success') => setLogs(old => [{ time: new Date().toLocaleTimeString('en-GB'), title, detail, type }, ...old].slice(0, 12))
  const flash = (message: string) => { setNotice(message); window.setTimeout(() => setNotice(''), 2800) }
  const toggleVM = (id: string) => {
    setVms(old => old.map(vm => vm.id === id ? { ...vm, status: vm.status === 'Running' ? 'Stopped' : 'Running', cpu: vm.status === 'Running' ? 0 : 18, ram: vm.status === 'Running' ? 0 : 36 } : vm))
    const vm = vms.find(v => v.id === id)
    if (vm) { addLog(`${vm.status === 'Running' ? 'Stop' : 'Start'} action simulated`, `${vm.name} · ${vm.id}`, 'info'); flash(`Demo action recorded for ${vm.name}`) }
  }
  const createVM = () => {
    if (!vmName.trim()) { flash('Enter a VM name first.'); return }
    const newVM: VM = { id: `VM-${String(vms.length + 1).padStart(3, '0')}`, name: vmName.trim().toLowerCase().replace(/\s+/g, '-'), image: 'Ubuntu 24.04 LTS', node: vmNode, cpu: 0, ram: 0, disk: 0, status: 'Provisioning', ip: 'Pending' }
    setVms(old => [...old, newVM]); addLog('VM provisioning simulated', `${newVM.name} · ${vmNode}`, 'info')
    setShowCreate(false); setVmName(''); flash('Demo VM added to inventory.')
  }
  const exportLogs = () => {
    const content = ['time,type,title,detail', ...logs.map(l => `"${l.time}","${l.type}","${l.title}","${l.detail}"`)].join('\n')
    const url = URL.createObjectURL(new Blob([content], { type: 'text/csv' }))
    const a = document.createElement('a'); a.href = url; a.download = 'nexus-activity-logs.csv'; a.click(); URL.revokeObjectURL(url)
    flash('Activity log CSV exported.')
  }
  if (!loggedIn) return <div className={`login-shell ${dark ? 'theme-dark' : 'theme-light'}`}>
    <div className="login-left">
      <div className="login-brand"><Brand/><span>NEXUS<span className="brand-dot">.</span></span><span className="brand-divider"/> <small>INFRASTRUCTURE CONTROL</small></div>
      <div className="login-hero">
        <div className="eyebrow"><span className="pulse-dot"/> AIORI-3 · PS-023 PROTOTYPE</div>
        <h1>One control plane.<br/><span>Two nodes.</span><br/>Zero guesswork.</h1>
        <p>A minimal, secure control layer for managing virtual machines across a two-node hypervisor cluster.</p>
        <div className="login-stats"><div><strong>02</strong><span>Hypervisor nodes</span></div><div><strong>05</strong><span>Demo instances</span></div><div><strong>99.9%</strong><span>Target availability</span></div></div>
      </div>
      <div className="login-footer"><span>● SIMULATION ENVIRONMENT</span><span>BUILD 0.9.3 · OCT 2026</span></div>
    </div>
    <div className="login-right">
      <button className="theme-toggle login-theme" onClick={() => setDark(!dark)} aria-label="Toggle theme">{dark ? <Sun size={16}/> : <Moon size={16}/>}<span>{dark ? 'Light mode' : 'Dark mode'}</span></button>
      <form className="login-card" onSubmit={e => { e.preventDefault(); setLoggedIn(true); addLog('Operator signed in', email, 'success') }}>
        <div className="login-icon"><LockKeyhole size={21}/></div>
        <div className="eyebrow">SECURE ACCESS</div>
        <h2>Welcome back</h2><p className="muted">Sign in to your control workspace.</p>
        <label>Email address</label><div className="input-wrap"><Users size={17}/><input type="email" value={email} onChange={e => setEmail(e.target.value)} required /></div>
        <label>Password</label><div className="input-wrap"><LockKeyhole size={17}/><input type="password" value={password} onChange={e => setPassword(e.target.value)} required /></div>
        <div className="login-options"><span><span className="check-square"><Check size={11}/></span> Demo workspace</span><a href="#demo" onClick={e => {e.preventDefault();setEmail('operator@nexus.demo');setPassword('nexus-demo')}}>Use demo credentials</a></div>
        <button className="primary-btn login-submit" type="submit">Access workspace <ArrowUpRight size={17}/></button>
        <div className="login-security"><ShieldCheck size={15}/> Prototype access · No real infrastructure connected</div>
      </form>
      <div className="login-bottom">Built for AIORI-3 Hackathon <span>·</span> PS-023</div>
    </div>
  </div>

  return <div className={`app-shell ${dark ? 'theme-dark' : 'theme-light'}`}>
    {mobileNav && <div className="mobile-backdrop" onClick={() => setMobileNav(false)} />}
    <aside className={`sidebar ${mobileNav ? 'sidebar-open' : ''}`}>
      <div className="sidebar-brand"><Brand/><span>NEXUS<span className="brand-dot">.</span></span><button className="mobile-close icon-btn" onClick={() => setMobileNav(false)}><X size={17}/></button></div>
      <div className="workspace-switch"><div className="workspace-avatar">N</div><div className="workspace-meta"><strong>Core Infrastructure</strong><span>Demo environment</span></div><ChevronDown size={15}/></div>
      {['WORKSPACE','OBSERVABILITY','SYSTEM'].map(group => <div className="nav-group" key={group}><div className="nav-label">{group}</div>{navItems.filter(n => n.group === group).map(item => { const Icon = item.icon; return <button key={item.name} className={`nav-item ${page === item.name ? 'active' : ''}`} onClick={() => {setPage(item.name);setMobileNav(false)}}><Icon size={17}/><span>{item.name}</span>{item.name === 'Virtual Machines' && <small>{vms.length}</small>}</button> })}</div>)}
      <div className="sidebar-spacer"/>
      <div className="cluster-health"><div className="cluster-health-head"><span className="pulse-dot"/> CLUSTER HEALTH</div><div className="health-main"><strong>Operational</strong><span>2/2 nodes online</span></div><div className="health-line"><span/></div><div className="health-foot"><span>Uptime</span><strong>14d 06h 22m</strong></div></div>
      <div className="sidebar-user"><div className="user-avatar">SS</div><div className="user-info"><strong>Sneha Singh</strong><span>System Operator</span></div><button className="icon-btn" onClick={() => setConfirmLogout(true)} title="Sign out"><LogOut size={16}/></button></div>
    </aside>

    <main className="main-area">
      <header className="topbar"><div className="topbar-left"><button className="icon-btn mobile-menu" onClick={() => setMobileNav(true)}><Menu size={19}/></button><div className="breadcrumb"><span>Workspace</span><span className="crumb-slash">/</span><strong>{page}</strong></div><span className="env-pill"><span/> DEMO</span></div><div className="topbar-actions"><div className="top-search"><Search size={15}/><input placeholder="Search anything..." value={search} onChange={e => setSearch(e.target.value)} /><kbd>⌘ K</kbd></div><button className="icon-btn theme-icon" onClick={() => setDark(!dark)} title="Toggle light/dark mode">{dark ? <Sun size={17}/> : <Moon size={17}/>}</button><button className="icon-btn notification-btn" onClick={() => {setPage('Activity Logs');flash('Showing recent system activity.')}} title="Notifications"><Bell size={17}/><i/></button><div className="top-avatar">SS</div></div></header>
      <div className="content-wrap">
        {notice && <div className="toast"><Check size={16}/>{notice}<button onClick={() => setNotice('')}><X size={14}/></button></div>}
        <div className="page-heading"><div><div className="eyebrow"><span className="pulse-dot"/> CONTROL PLANE / {page.toUpperCase()}</div><h1>{page === 'Overview' ? 'System overview' : page}</h1><p>{page === 'Overview' ? 'Your infrastructure at a glance. All metrics shown are simulated demo data.' : page === 'Virtual Machines' ? 'Provision, inspect, and manage virtual machine instances.' : page === 'Cluster Nodes' ? 'Monitor the health and capacity of your two-node cluster.' : page === 'Monitoring' ? 'Resource telemetry and performance signals across your cluster.' : page === 'Activity Logs' ? 'A traceable timeline of control-plane actions and system events.' : 'Manage workspace preferences and control-plane behavior.'}</p></div><div className="heading-actions"><span className="last-updated"><span className="pulse-dot"/> DEMO DATA</span>{page === 'Virtual Machines' && <button className="primary-btn" onClick={() => setShowCreate(true)}><Plus size={16}/> Create VM</button>}</div></div>

        {page === 'Overview' && <>
          <div className="notice-banner"><div className="notice-symbol"><ShieldCheck size={18}/></div><div><strong>Prototype mode is active</strong><p>VM controls and metrics are simulated locally. No real hypervisor APIs are connected.</p></div><span className="notice-tag">SAFE DEMO</span></div>
          <div className="stats-grid">
            <div className="stat-card"><div className="stat-top"><span>Virtual machines</span><span className="stat-icon violet"><Server size={17}/></span></div><div className="stat-value">{vms.length}<span className="stat-unit"> instances</span></div><div className="stat-foot"><span className="positive"><ArrowUpRight size={14}/> +2</span><span>vs. last deployment</span></div><div className="stat-spark"><MiniBars/></div></div>
            <div className="stat-card"><div className="stat-top"><span>Running instances</span><span className="stat-icon green"><Activity size={17}/></span></div><div className="stat-value">{running}<span className="stat-unit"> / {vms.length}</span></div><div className="stat-foot"><span className="positive"><Check size={13}/> Healthy</span><span>{Math.round(running / Math.max(vms.length,1) * 100)}% availability</span></div><div className="stat-spark"><MiniBars/></div></div>
            <div className="stat-card"><div className="stat-top"><span>CPU utilization</span><span className="stat-icon blue"><Cpu size={17}/></span></div><div className="stat-value">42<span className="stat-unit">%</span></div><div className="stat-foot"><span className="positive"><ArrowDownRight size={14}/> 4.2%</span><span>vs. previous hour</span></div><Meter value={42}/></div>
            <div className="stat-card"><div className="stat-top"><span>Memory allocated</span><span className="stat-icon orange"><Database size={17}/></span></div><div className="stat-value">68<span className="stat-unit">%</span></div><div className="stat-foot"><span className="warning-text"><AlertTriangle size={13}/> Near threshold</span><span>43.5 / 64 GB</span></div><Meter value={68} color="orange"/></div>
          </div>
          <div className="dashboard-grid">
            <section className="panel resource-panel"><div className="panel-head"><div><h3>Resource utilization</h3><p>Aggregate cluster performance</p></div><button className="select-chip" onClick={() => setPage('Monitoring')}>Last 24 hours <ChevronDown size={13}/></button></div><div className="chart-legend"><span><i className="legend-dot cpu-dot"/> CPU</span><span><i className="legend-dot mem-dot"/> Memory</span><span className="chart-live"><span className="pulse-dot"/> LIVE SIMULATION</span></div><div className="chart-area"><div className="chart-ylabels"><span>100%</span><span>75%</span><span>50%</span><span>25%</span><span>0%</span></div><div className="chart-plot"><div className="chart-gridlines"><i/><i/><i/><i/><i/></div><svg viewBox="0 0 720 220" preserveAspectRatio="none" className="line-chart"><defs><linearGradient id="cpuFill" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#6687ff" stopOpacity=".24"/><stop offset="100%" stopColor="#6687ff" stopOpacity="0"/></linearGradient></defs><path d="M0 145 C30 130 35 150 65 125 S110 100 130 122 S170 140 195 95 S230 110 260 87 S305 100 330 73 S365 115 395 95 S435 60 460 82 S500 98 525 56 S560 80 590 66 S630 45 650 70 S690 44 720 48 L720 220 L0 220 Z" fill="url(#cpuFill)"/><path d="M0 145 C30 130 35 150 65 125 S110 100 130 122 S170 140 195 95 S230 110 260 87 S305 100 330 73 S365 115 395 95 S435 60 460 82 S500 98 525 56 S560 80 590 66 S630 45 650 70 S690 44 720 48" fill="none" stroke="#7d93ff" strokeWidth="2.5" vectorEffect="non-scaling-stroke"/><path d="M0 175 C30 168 50 180 75 160 S115 170 145 154 S185 170 215 145 S260 160 290 135 S330 155 365 137 S400 155 430 127 S470 145 500 122 S540 143 575 115 S610 126 640 105 S685 120 720 101" fill="none" stroke="#2dd4bf" strokeWidth="2" strokeDasharray="5 4" vectorEffect="non-scaling-stroke"/></svg><div className="chart-xlabels"><span>00:00</span><span>04:00</span><span>08:00</span><span>12:00</span><span>16:00</span><span>20:00</span><span>Now</span></div></div></div></section>
            <section className="panel nodes-panel"><div className="panel-head"><div><h3>Cluster nodes</h3><p>Two-node high availability</p></div><button className="icon-btn" onClick={() => setPage('Cluster Nodes')}><MoreHorizontal size={18}/></button></div><div className="node-card"><div className="node-top"><div className="node-icon"><Server size={18}/></div><div className="node-title"><strong>NODE-01</strong><span>Primary · 10.0.0.11</span></div><Status status="Online"/></div><div className="node-metrics"><div><span>CPU</span><strong>46%</strong><Meter value={46}/></div><div><span>Memory</span><strong>78%</strong><Meter value={78} color="orange"/></div></div><div className="node-bottom"><span><Cpu size={13}/> 16 vCPU</span><span><Database size={13}/> 32 GB RAM</span></div></div><div className="node-card"><div className="node-top"><div className="node-icon teal"><Server size={18}/></div><div className="node-title"><strong>NODE-02</strong><span>Secondary · 10.0.0.12</span></div><Status status="Online"/></div><div className="node-metrics"><div><span>CPU</span><strong>31%</strong><Meter value={31}/></div><div><span>Memory</span><strong>57%</strong><Meter value={57} color="teal"/></div></div><div className="node-bottom"><span><Cpu size={13}/> 16 vCPU</span><span><Database size={13}/> 32 GB RAM</span></div></div><button className="text-link" onClick={() => setPage('Cluster Nodes')}>View node details <ArrowUpRight size={14}/></button></section>
          </div>
          <div className="panel vm-panel"><div className="panel-head"><div><h3>Virtual machine inventory</h3><p>Recently active instances across your cluster</p></div><button className="text-link" onClick={() => setPage('Virtual Machines')}>View all VMs <ArrowUpRight size={14}/></button></div><VMTable vms={filteredVMs.slice(0,4)} toggleVM={toggleVM}/></div>
          <div className="bottom-grid"><section className="panel events-panel"><div className="panel-head"><div><h3>Recent activity</h3><p>Latest control-plane events</p></div><button className="text-link" onClick={() => setPage('Activity Logs')}>Full log <ArrowUpRight size={14}/></button></div><div className="event-list">{logs.slice(0,3).map((log,i)=><div className="event-row" key={i}><div className={`event-icon ${log.type}`}><Activity size={14}/></div><div className="event-text"><strong>{log.title}</strong><span>{log.detail}</span></div><time>{log.time}</time></div>)}</div></section><section className="panel quick-panel"><div className="panel-head"><div><h3>Quick actions</h3><p>Common operator tasks</p></div></div><button className="quick-action" onClick={() => setShowCreate(true)}><span className="quick-icon"><Plus size={16}/></span><span><strong>Provision a VM</strong><small>Launch a new instance</small></span><ArrowUpRight size={15}/></button><button className="quick-action" onClick={() => {addLog('Cluster health check triggered','Manual health check simulated.','success');flash('Health check completed (demo).')}}><span className="quick-icon"><ShieldCheck size={16}/></span><span><strong>Run health check</strong><small>Validate node availability</small></span><ArrowUpRight size={15}/></button><button className="quick-action" onClick={exportLogs}><span className="quick-icon"><Download size={16}/></span><span><strong>Export activity log</strong><small>Download as CSV</small></span><ArrowUpRight size={15}/></button></section></div>
        </>}

        {page === 'Virtual Machines' && <section className="panel full-panel"><div className="panel-head"><div><h3>Instance inventory <span className="count-pill">{filteredVMs.length}</span></h3><p>Demo data · actions are simulated</p></div><button className="secondary-btn" onClick={exportLogs}><Download size={15}/> Export logs</button></div><VMTable vms={filteredVMs} toggleVM={toggleVM}/></section>}
        {page === 'Cluster Nodes' && <><div className="stats-grid three-stats"><Stat title="Nodes online" value="2 / 2" icon={<Network size={17}/>} note="All nodes responding" color="green"/><Stat title="Cluster CPU" value="38.5%" icon={<Cpu size={17}/>} note="Within normal range" color="blue"/><Stat title="Total memory" value="43.5 GB" icon={<Database size={17}/>} note="Of 64 GB provisioned" color="orange"/></div><div className="node-detail-grid">{[{id:'NODE-01',role:'Primary hypervisor',ip:'10.0.0.11',cpu:46,ram:78,vm:3,uptime:'14d 06h 22m',serial:'NX-HV-0001'},{id:'NODE-02',role:'Secondary hypervisor',ip:'10.0.0.12',cpu:31,ram:57,vm:2,uptime:'14d 06h 19m',serial:'NX-HV-0002'}].map(n=><section className="panel node-detail" key={n.id}><div className="node-detail-header"><div className="node-icon large"><Server size={21}/></div><div><h3>{n.id}</h3><p>{n.role}</p></div><Status status="Online"/></div><div className="node-detail-ip"><Network size={14}/>{n.ip}<span>·</span>{n.serial}</div><div className="big-meter"><div><span>CPU utilization</span><strong>{n.cpu}%</strong></div><Meter value={n.cpu}/></div><div className="big-meter"><div><span>Memory utilization</span><strong>{n.ram}%</strong></div><Meter value={n.ram} color={n.ram>70?'orange':'teal'}/></div><div className="node-detail-stats"><div><span>Assigned VMs</span><strong>{n.vm}</strong></div><div><span>Uptime</span><strong>{n.uptime}</strong></div><div><span>Health</span><strong className="healthy">Healthy</strong></div></div><button className="secondary-btn wide" onClick={() => {addLog('Node diagnostics simulated',`${n.id} · All checks passed.`);flash(`${n.id}: all demo checks passed.`)}}><Activity size={15}/> Run diagnostics</button></section>)}</div><section className="panel"><div className="panel-head"><div><h3>Cluster configuration</h3><p>Reference architecture for PS-023</p></div><span className="notice-tag">2-NODE</span></div><div className="architecture"><div className="arch-box controller"><Command size={22}/><strong>NEXUS Controller</strong><small>Central control plane</small></div><div className="arch-connector"><span>API / SSH (planned)</span><i/><i/></div><div className="arch-nodes"><div className="arch-box"><Server size={20}/><strong>NODE-01</strong><small>Primary · KVM/QEMU</small></div><div className="arch-box"><Server size={20}/><strong>NODE-02</strong><small>Secondary · KVM/QEMU</small></div></div></div></section></>}
        {page === 'Monitoring' && <><div className="stats-grid three-stats"><Stat title="CPU (aggregate)" value="38.5%" icon={<Cpu size={17}/>} note="−4.2% from previous hour" color="blue"/><Stat title="Memory in use" value="68.0%" icon={<Database size={17}/>} note="43.5 GB of 64 GB" color="orange"/><Stat title="Storage allocated" value="46.8%" icon={<HardDrive size={17}/>} note="468 GB of 1 TB" color="green"/></div><section className="panel monitoring-chart"><div className="panel-head"><div><h3>Performance telemetry</h3><p>Illustrative 24-hour resource trend</p></div><span className="notice-tag">SAMPLE DATA</span></div><div className="monitor-lines"><div className="monitor-line"><div><span className="legend-dot cpu-dot"/> CPU usage <strong>38.5%</strong></div><Meter value={38.5}/><small>Peak 71% · Average 42%</small></div><div className="monitor-line"><div><span className="legend-dot mem-dot"/> Memory usage <strong>68%</strong></div><Meter value={68} color="teal"/><small>Peak 78% · Average 61%</small></div><div className="monitor-line"><div><span className="legend-dot disk-dot"/> Storage usage <strong>46.8%</strong></div><Meter value={46.8} color="violet"/><small>Peak 49% · Average 44%</small></div><div className="monitor-line"><div><span className="legend-dot net-dot"/> Network I/O <strong>24.6 MB/s</strong></div><Meter value={24.6} color="orange"/><small>Peak 82 MB/s · Average 28 MB/s</small></div></div></section><section className="panel"><div className="panel-head"><div><h3>Threshold alerts</h3><p>Configured sample alert rules</p></div><Status status="Active"/></div><div className="alert-rule"><div className="alert-rule-icon warning-text"><AlertTriangle size={17}/></div><div><strong>High memory utilization</strong><p>Trigger when node memory exceeds 75% for 5 minutes.</p></div><span className="rule-threshold">75%</span><Status status="Triggered"/></div><div className="alert-rule"><div className="alert-rule-icon"><Gauge size={17}/></div><div><strong>High CPU utilization</strong><p>Trigger when node CPU exceeds 85% for 3 minutes.</p></div><span className="rule-threshold">85%</span><Status status="Healthy"/></div><div className="alert-rule"><div className="alert-rule-icon"><Network size={17}/></div><div><strong>Node heartbeat</strong><p>Trigger when a node misses 3 consecutive heartbeats.</p></div><span className="rule-threshold">3 misses</span><Status status="Healthy"/></div></section></>}
        {page === 'Activity Logs' && <section className="panel full-panel"><div className="panel-head"><div><h3>Event timeline <span className="count-pill">{logs.length}</span></h3><p>Audit trail for this browser session</p></div><button className="secondary-btn" onClick={exportLogs}><Download size={15}/> Export CSV</button></div><div className="log-list">{logs.map((log,i)=><div className="log-row" key={`${log.time}-${i}`}><div className={`event-icon ${log.type}`}><Activity size={14}/></div><div className="log-main"><strong>{log.title}</strong><span>{log.detail}</span></div><span className={`log-type ${log.type}`}>{log.type}</span><time>{log.time}</time></div>)}</div><p className="footnote"><ShieldCheck size={14}/> Logs are local demo records and are not sent to a server.</p></section>}
        {page === 'Settings' && <div className="settings-grid"><section className="panel settings-panel"><div className="panel-head"><div><h3>Workspace preferences</h3><p>Customize your operator experience</p></div></div><div className="setting-row"><div className="setting-icon"><Sun size={17}/></div><div className="setting-copy"><strong>Appearance</strong><span>Switch between light and dark themes.</span></div><button className="secondary-btn" onClick={() => setDark(!dark)}>{dark ? <Sun size={15}/> : <Moon size={15}/>} {dark ? 'Light mode' : 'Dark mode'}</button></div><div className="setting-row"><div className="setting-icon"><Bell size={17}/></div><div className="setting-copy"><strong>System notifications</strong><span>Show in-app alerts for demo events.</span></div><button className={`switch ${alerts?'on':''}`} onClick={() => setAlerts(!alerts)} aria-label="Toggle notifications"><span/></button></div><div className="setting-row"><div className="setting-icon"><Zap size={17}/></div><div className="setting-copy"><strong>Auto-balance placement</strong><span>Suggest balancing VMs between nodes.</span></div><button className={`switch ${autoBalance?'on':''}`} onClick={() => setAutoBalance(!autoBalance)} aria-label="Toggle auto-balance"><span/></button></div><div className="setting-row"><div className="setting-icon"><LockKeyhole size={17}/></div><div className="setting-copy"><strong>Session security</strong><span>Demo session · no backend authentication.</span></div><span className="notice-tag">DEMO</span></div></section><section className="panel settings-panel"><div className="panel-head"><div><h3>System information</h3><p>Current prototype build details</p></div></div><div className="info-row"><span>Project</span><strong>NEXUS Control Plane</strong></div><div className="info-row"><span>Problem statement</span><strong>AIORI-3 · PS-023</strong></div><div className="info-row"><span>Frontend</span><strong>React + TypeScript</strong></div><div className="info-row"><span>Build</span><strong>0.9.3-prototype</strong></div><div className="info-row"><span>Execution mode</span><strong className="warning-text">Simulated</strong></div><div className="settings-callout"><CircleHelp size={16}/><p>Connect a backend adapter for libvirt/KVM before using this interface with real infrastructure.</p></div></section></div>}
        <footer className="app-footer"><span>© 2026 NEXUS CONTROL PLANE <i/> AIORI-3 · PS-023</span><span><span className="pulse-dot"/> ALL SYSTEMS NOMINAL <i/> v0.9.3</span></footer>
      </div>
    </main>

    {showCreate && <div className="modal-backdrop" onClick={() => setShowCreate(false)}><form className="modal-card" onClick={e => e.stopPropagation()} onSubmit={e => {e.preventDefault();createVM()}}><div className="modal-header"><div><span className="eyebrow">INSTANCE MANAGEMENT</span><h2>Create virtual machine</h2><p>Creates a sample entry in the local demo inventory.</p></div><button type="button" className="icon-btn" onClick={() => setShowCreate(false)}><X size={18}/></button></div><label>Instance name</label><input className="form-input" placeholder="e.g. analytics-worker-01" value={vmName} onChange={e => setVmName(e.target.value)} autoFocus/><label>Target node</label><select className="form-input" value={vmNode} onChange={e => setVmNode(e.target.value)}><option>NODE-01</option><option>NODE-02</option></select><div className="modal-note"><AlertTriangle size={15}/> Demo only — this will not provision a real VM.</div><div className="modal-actions"><button type="button" className="secondary-btn" onClick={() => setShowCreate(false)}>Cancel</button><button type="submit" className="primary-btn"><Plus size={15}/> Add demo VM</button></div></form></div>}
    {confirmLogout && <div className="modal-backdrop"><div className="modal-card"><div className="modal-header"><div><h2>Sign out?</h2><p>You'll return to the demo login screen.</p></div><button className="icon-btn" onClick={() => setConfirmLogout(false)}><X size={18}/></button></div><div className="modal-actions"><button className="secondary-btn" onClick={() => setConfirmLogout(false)}>Cancel</button><button className="primary-btn" onClick={() => {setLoggedIn(false);setConfirmLogout(false)}}><LogOut size={15}/> Sign out</button></div></div></div>}
  </div>
}

function Stat({ title, value, icon, note, color }: {title:string;value:string;icon:React.ReactNode;note:string;color:string}) {
  return <div className="stat-card"><div className="stat-top"><span>{title}</span><span className={`stat-icon ${color}`}>{icon}</span></div><div className="stat-value">{value}</div><div className="stat-foot"><span>{note}</span></div><Meter value={parseFloat(value) || 50} color={color}/></div>
}
function VMTable({ vms, toggleVM }: {vms:VM[];toggleVM:(id:string)=>void}) {
  return <div className="table-scroll"><table className="vm-table"><thead><tr><th>INSTANCE</th><th>STATUS</th><th>NODE</th><th>CPU</th><th>MEMORY</th><th>PRIVATE IP</th><th>ACTION</th></tr></thead><tbody>{vms.map(vm=><tr key={vm.id}><td><div className="vm-name-cell"><div className="vm-icon"><Server size={16}/></div><div><strong>{vm.name}</strong><span>{vm.id} · {vm.image}</span></div></div></td><td><Status status={vm.status}/></td><td><span className="node-chip">{vm.node}</span></td><td><div className="table-meter"><span>{vm.cpu}%</span><Meter value={vm.cpu}/></div></td><td><div className="table-meter"><span>{vm.ram}%</span><Meter value={vm.ram} color="teal"/></div></td><td><code>{vm.ip}</code></td><td><button className="action-btn" title={vm.status==='Running'?'Stop demo VM':'Start demo VM'} onClick={() => toggleVM(vm.id)} disabled={vm.status==='Provisioning'}><Power size={14}/>{vm.status==='Running'?'Stop':vm.status==='Stopped'?'Start':'Pending'}</button></td></tr>)}</tbody></table>{vms.length===0 && <div className="empty-state"><Search size={22}/><strong>No instances found</strong><span>Try a different search term.</span></div>}</div>
}